package com.mrnova.fxbot

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

/**
 * MR NOVA FX BOT starter app.
 * DEMO ONLY: no Quotex connection, no live price feed, no real orders.
 * CALL/PUT outcomes are random demo placeholders, not trading signals.
 */
class MainActivity : Activity() {
    private val bg = Color.rgb(10, 10, 12)
    private val panel = Color.rgb(23, 23, 27)
    private val gold = Color.rgb(226, 183, 85)
    private val muted = Color.rgb(165, 165, 172)
    private val green = Color.rgb(48, 190, 123)
    private val red = Color.rgb(224, 88, 88)

    private var running = false
    private var wins = 0
    private var losses = 0
    private var demoPnl = 0.0
    private val stake = 100.0
    private val historyItems = mutableListOf<String>()

    private lateinit var status: TextView
    private lateinit var signal: TextView
    private lateinit var tradeCount: TextView
    private lateinit var winCount: TextView
    private lateinit var lossCount: TextView
    private lateinit var pnl: TextView
    private lateinit var history: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(22))
            setBackgroundColor(bg)
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("MR NOVA FX BOT", 25, gold, true))
        root.addView(text("LUXURY TRADING DASHBOARD", 11, muted, true).apply {
            setPadding(0, dp(3), 0, dp(14))
        })

        root.addView(sectionTitle("ACCOUNT / MARKET"))
        root.addView(card {
            addView(text("DEMO ONLY", 12, gold, true))
            addView(text("Quotex OTC • M1 chart • 2-minute expiry", 14, Color.WHITE, true)
                .apply { setPadding(0, dp(8), 0, dp(4)) })
            addView(text("No live platform connection", 12, muted))
        })

        root.addView(sectionTitle("MARKET ANALYSIS"))
        root.addView(card {
            addView(text("Waiting for market data", 17, Color.WHITE, true))
            addView(text("FVG • Support/Resistance • EMA 50/200 • RSI 14", 12, muted)
                .apply { setPadding(0, dp(7), 0, dp(7)) })
            addView(text("This version does not receive OTC candles or calculate real trading signals.", 12, muted))
        })

        root.addView(sectionTitle("BOT CONTROL"))
        root.addView(card {
            signal = text("No demo signal yet", 14, gold, true)
            addView(signal)
            status = text("● STOPPED", 15, red, true).apply {
                setPadding(0, dp(9), 0, dp(4))
            }
            addView(status)
            addView(row {
                addView(button("START DEMO", gold, Color.BLACK) {
                    running = true
                    status.text = "● DEMO RUNNING"
                    status.setTextColor(green)
                    signal.text = "Demo mode active — waiting for real market data"
                }, weight(1f))
                addView(spacer(dp(8)))
                addView(button("STOP", red, Color.WHITE) {
                    running = false
                    status.text = "● STOPPED"
                    status.setTextColor(red)
                }, weight(1f))
            })
        })

        root.addView(sectionTitle("DEMO TRADE SIMULATOR"))
        root.addView(card {
            addView(text("Demo stake: 100 units", 14, Color.WHITE, true))
            addView(text("Random outcomes only. These buttons do not place real trades.", 12, muted)
                .apply { setPadding(0, dp(6), 0, dp(10)) })
            addView(row {
                addView(button("CALL ↑", green, Color.BLACK) { simulateTrade("CALL") }, weight(1f))
                addView(spacer(dp(8)))
                addView(button("PUT ↓", red, Color.WHITE) { simulateTrade("PUT") }, weight(1f))
            })
        })

        root.addView(sectionTitle("SIMULATED PERFORMANCE"))
        root.addView(card {
            tradeCount = text("Trades: 0", 14, Color.WHITE, true)
            winCount = text("Wins: 0", 14, green, true)
            lossCount = text("Losses: 0", 14, red, true)
            pnl = text("Demo P/L: 0.00 units", 14, gold, true)
            addView(tradeCount)
            addView(winCount.apply { setPadding(0, dp(7), 0, 0) })
            addView(lossCount.apply { setPadding(0, dp(7), 0, 0) })
            addView(pnl.apply { setPadding(0, dp(7), 0, 0) })
        })

        root.addView(sectionTitle("TRADE HISTORY"))
        root.addView(card {
            history = text("No demo trades yet.", 12, muted)
            addView(history)
        })

        root.addView(text(
            "Risk notice: Binary options are high risk. A 90% win rate is not guaranteed. " +
                "This is a starter demo, not a real-money trading system.",
            11, muted
        ).apply { setPadding(dp(2), dp(12), dp(2), 0) })
    }

    private fun simulateTrade(direction: String) {
        if (!running) {
            signal.text = "Tap START DEMO first"
            return
        }
        // Random placeholder outcomes: not based on candles or strategy indicators.
        val won = Random.nextBoolean()
        val result = if (won) {
            wins++
            demoPnl += stake * 0.8
            "WIN"
        } else {
            losses++
            demoPnl -= stake
            "LOSS"
        }
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        historyItems.add(0, "$stamp  $direction  $result")
        if (historyItems.size > 8) historyItems.removeAt(historyItems.lastIndex)
        signal.text = "$direction demo result: $result"
        tradeCount.text = "Trades: ${wins + losses}"
        winCount.text = "Wins: $wins"
        lossCount.text = "Losses: $losses"
        pnl.text = "Demo P/L: ${"%.2f".format(Locale.US, demoPnl)} units"
        history.text = historyItems.joinToString("\n")
    }

    private fun sectionTitle(s: String) = text(s, 12, gold, true).apply {
        setPadding(dp(2), dp(16), 0, dp(8))
    }

    private fun card(build: LinearLayout.() -> Unit): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(panel)
            build()
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = dp(10)
            }
        }

    private fun row(build: LinearLayout.() -> Unit) =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            build()
        }

    private fun text(s: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = s
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun button(label: String, color: Int, textColor: Int, action: () -> Unit) =
        Button(this).apply {
            text = label
            setTextColor(textColor)
            setBackgroundColor(color)
            textSize = 12f
            setOnClickListener { action() }
        }

    private fun spacer(width: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(width, 1)
    }

    private fun weight(w: Float) = LinearLayout.LayoutParams(0, dp(48), w)
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
