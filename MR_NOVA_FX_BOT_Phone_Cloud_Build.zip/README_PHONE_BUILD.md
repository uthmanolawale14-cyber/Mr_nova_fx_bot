# MR NOVA FX BOT — build from your Android phone

This project contains Android source code and a GitHub Actions workflow that can build a debug APK in the cloud. It has not been built or tested in this chat.

## Phone-only cloud build path
1. Download and extract this ZIP on your Android phone.
2. In Chrome, sign in to GitHub and create a new repository named `mr-nova-fx-bot`.
3. Upload the extracted project files and folders to the repository. Include the hidden `.github/workflows/build-apk.yml` file. If mobile upload makes hidden folders difficult, use GitHub's web upload page in desktop-site mode, or tell me what you see and I'll guide you.
4. Open the repository's **Actions** tab. Select **Build MR NOVA FX BOT APK** and tap **Run workflow**. The workflow also runs on pushes to `main`.
5. When the workflow finishes successfully, open its run, find **Artifacts**, and download `MR-NOVA-FX-BOT-debug-APK`.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`, then tap the APK to install. Android may ask you to allow installs from your browser or file manager; only enable this for the app you intentionally used, then disable it again afterward.

## What's included
- Black-and-gold Android dashboard
- Start/stop demo controls
- Random demo CALL/PUT outcomes and history
- Cloud build workflow

## Important
- This is DEMO ONLY: no Quotex login, OTC price feed, or real order execution.
- Demo outcomes are random placeholders, not actual FVG/SR/EMA/RSI signals and not a backtest.
- 90% win rate is not guaranteed.
- Never upload account passwords, API keys, or other secrets to a public repository. Keep the repository private if you prefer.
- GitHub account and Actions availability/usage limits may apply.
